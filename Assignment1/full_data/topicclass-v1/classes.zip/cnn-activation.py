from collections import defaultdict
import time
import random
import torch
import pickle
import numpy as np
import datetime
import os
import pdb

Tags = {}

class CNNclass(torch.nn.Module):
    def __init__(self, nwords, emb_size, num_filters, window_size, dropout, weight_constraint, ntags, use_cuda, Type, embedding=None):
        super(CNNclass, self).__init__()
        """ layers """
        self.embedding = torch.nn.Embedding(nwords, emb_size)
        if embedding is not None:
            self.embedding.weight.data.copy_(torch.from_numpy(embedding).type(Type))
            self.embedding.weight.requires_grad = True
        else:
            # uniform initialization
            if use_cuda:
                torch.nn.init.uniform_(self.embedding.weight, -0.25, 0.25).cuda()
            else:
                torch.nn.init.uniform_(self.embedding.weight, -0.25, 0.25)

        if use_cuda:
            # Conv
            # self.conv = {}
            # self.conv['conv_1d'] = torch.nn.Conv1d(in_channels=emb_size, out_channels=num_filters, kernel_size=3,
            #                                stride=1, padding=0, dilation=1, groups=1, bias=True).cuda()
            # self.conv['conv_2d'] = torch.nn.Conv1d(in_channels=emb_size, out_channels=num_filters, kernel_size=4,
            #                                stride=1, padding=0, dilation=1, groups=1, bias=True).cuda()
            # self.conv['conv_3d'] = torch.nn.Conv1d(in_channels=emb_size, out_channels=num_filters, kernel_size=5,
            #                                stride=1, padding=0, dilation=1, groups=1, bias=True).cuda()

            self.conv1d = torch.nn.Conv1d(in_channels=emb_size, out_channels=num_filters, kernel_size=3,
                                           stride=1, padding=0, dilation=1, groups=1, bias=True).cuda()
            self.conv2d = torch.nn.Conv1d(in_channels=emb_size, out_channels=num_filters, kernel_size=4,
                                           stride=1, padding=0, dilation=1, groups=1, bias=True).cuda()
            self.conv3d = torch.nn.Conv1d(in_channels=emb_size, out_channels=num_filters, kernel_size=5,
                                           stride=1, padding=0, dilation=1, groups=1, bias=True).cuda()

            self.relu = torch.nn.ReLU().cuda()
            self.projection_layer = torch.nn.Linear(in_features=num_filters*3, out_features=ntags, bias=True).cuda()
            # Initializing the projection layer
            torch.nn.init.xavier_uniform_(self.projection_layer.weight).cuda()

            # Drop out layer
            self.drop_layer = torch.nn.Dropout(p=dropout).cuda()

            # Weight constraint
            self.weight_norm = weight_constraint

        else:
            # Conv
            self.conv = {}
            # self.conv['conv_1d'] = torch.nn.Conv1d(in_channels=emb_size, out_channels=num_filters, kernel_size=3,
            #                                stride=1, padding=0, dilation=1, groups=1, bias=True)
            # self.conv['conv_2d'] = torch.nn.Conv1d(in_channels=emb_size, out_channels=num_filters, kernel_size=4,
            #                                stride=1, padding=0, dilation=1, groups=1, bias=True)
            # self.conv['conv_3d'] = torch.nn.Conv1d(in_channels=emb_size, out_channels=num_filters, kernel_size=5,
            #                                stride=1, padding=0, dilation=1, groups=1, bias=True)

            self.conv1d = torch.nn.Conv1d(in_channels=emb_size, out_channels=num_filters, kernel_size=3,
                                           stride=1, padding=0, dilation=1, groups=1, bias=True)
            self.conv2d = torch.nn.Conv1d(in_channels=emb_size, out_channels=num_filters, kernel_size=4,
                                           stride=1, padding=0, dilation=1, groups=1, bias=True)
            self.conv3d = torch.nn.Conv1d(in_channels=emb_size, out_channels=num_filters, kernel_size=5,
                                           stride=1, padding=0, dilation=1, groups=1, bias=True)

            self.relu = torch.nn.ReLU()
            self.projection_layer = torch.nn.Linear(in_features=num_filters*3, out_features=ntags, bias=True)
            # Initializing the projection layer
            torch.nn.init.xavier_uniform_(self.projection_layer.weight)

            # Drop out layer
            self.drop_layer = torch.nn.Dropout(p=dropout)

            # Weight constraint
            self.weight_norm = weight_constraint


    def forward(self, words, return_activations=False):
        emb = self.embedding(words)                 # nwords x emb_size
        emb = emb.unsqueeze(0).permute(0, 2, 1)     # 1 x emb_size x nwords
        # h_features = []
        # for conv_filter in self.conv.values():
        #     h = conv_filter(emb)                       # 1 x num_filters x nwords
        #     if return_activations:
        #         activations = h.squeeze(0).max(dim=1)      # argmax along length of the sentence
        #     # Do max pooling
        #     h = h.max(dim=2)[0]                         # 1 x num_filters
        #     # h = activations.max(dim=2)[0]
        #     h = self.relu(h)
        #     features = h.squeeze(0)
        #     h_features.append(h)
        # h_features = torch.stack(h_features).view(-1, 1)

        h1 = self.relu(self.conv1d(emb).max(dim=2)[0]).squeeze(0)
        h2 = self.relu(self.conv2d(emb).max(dim=2)[0]).squeeze(0)
        h3 = self.relu(self.conv3d(emb).max(dim=2)[0]).squeeze(0)
        pdb.set_trace()
        h_normalized = torch.stack([h1, h2, h3]).view(-1, 1)

        # Drop out
        h_normalized = self.drop_layer(h_normalized).transpose(0, 1)

        out = self.projection_layer(h_normalized)              # size(out) = 1 x ntags

        # l2 norm constrain
        # norm = torch.norm(h_features, p=2, dim=0).detach()

        # qn = torch.norm(q, p=2, dim=1).detach()
        # q = q.div(qn.expand_as(q))
        # h_normalized = h_features.div((norm / self.weight_norm).expand(h_features.size()[0]))
        # h_normalized = [self.weight_norm*x / norm for x in h_features]

        # h_normalized = h_features * (self.weight_norm / norm)
        # h_normalized = h_features

        if return_activations:
            return out, activations.data.cpu().numpy(), h_features.data.cpu().numpy()
        return out


np.set_printoptions(linewidth=np.nan, threshold=np.nan)

# Functions to read in the corpus
w2i = defaultdict(lambda: len(w2i))
UNK = w2i["<unk>"]
PAD = w2i["pad"]
def read_dataset(filename):
    # Tags = {}
    global Tags
    with open(filename, "r", encoding='utf-8') as f:
        for line in f:
            tag, words = line.lower().strip().split(" ||| ")
            words = words.split(" ")
            if tag not in Tags.keys():
                Tags[tag] = len(Tags)
            yield (words, [w2i[x] for x in words], Tags[tag])

    # print('Number of labels: ', len(Tags))

def calc_predict_and_activations(wids, tag, words):
    if len(wids) < WIN_SIZE:
        wids += [0] * (WIN_SIZE-len(wids))
    words_tensor = torch.tensor(wids).type(type)
    scores, activations, features = model(words_tensor, return_activations=True)
    scores = scores.squeeze().cpu().data.numpy()
    print('%d ||| %s' % (tag, ' '.join(words)))
    predict = np.argmax(scores)
    print(display_activations(words, activations))
    W = model.projection_layer.weight.data.cpu().numpy()
    bias = model.projection_layer.bias.data.cpu().numpy()
    print('scores=%s, predict: %d' % (scores, predict))
    print('  bias=%s' % bias)
    try:
        contributions = W * features
    except:
        pdb.set_trace()
    print(' very bad (%.4f): %s' % (scores[0], contributions[0]))
    print('      bad (%.4f): %s' % (scores[1], contributions[1]))
    print('  neutral (%.4f): %s' % (scores[2], contributions[2]))
    print('     good (%.4f): %s' % (scores[3], contributions[3]))
    print('very good (%.4f): %s' % (scores[4], contributions[4]))


def display_activations(words, activations):
    pad_begin = (WIN_SIZE - 1) / 2
    pad_end = WIN_SIZE - 1 - pad_begin
    words_padded = ['pad' for _ in range(int(pad_begin))] + words + ['pad' for _ in range(int(pad_end))]

    ngrams = []
    for act in activations:
        ngrams.append('[' + ', '.join(words_padded[act:act+WIN_SIZE]) + ']')

    return ngrams

def load_embedding(gloveFile):
    f = open(gloveFile, 'r', encoding='utf-8')
    model = {}
    for line in f:
        splitLine = line.split()
        word = splitLine[0]
        embedding = np.array([float(val) for val in splitLine[1:]])
        model[word] = embedding
    print("Done.", len(model), " words loaded!")
    return model

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("-p", "--pattern", type=str, help="training patter", default="6B100d", choices=["rand", '6B100d', '6B200d', '6B300d', 'multichannel'])
    parser.add_argument("-m", "--mode", type=str, help="mode of training", default="normal",
                        choices=["normal", "toy"])
    parser.add_argument("-filt", "--filter", type=int, help="filter_size", default=100)
    parser.add_argument("-data", "--data", type=str, help="which dataset to use", default="all", choices=["all", "part"])
    parser.add_argument("-estop", "--early_stop", type=str, help="mode of early stopping", default="immediate",
                        choices=["no", "immediate", "tolerate"])
    parser.add_argument("-norm", "--weight_norm", type=float, help="norm of weight constraint", default=3)
    parser.add_argument("-tr", "--ratio", type=float, help="ratio of training data", default=1)
    parser.add_argument("-lyr", "--layers", type=int, help="layers of network", default=2)
    parser.add_argument("-hdd", "--hidden_size", type=int, help="hidden size of cells", default=500)
    parser.add_argument("-d", "--dropout", type=float, help="dropout probability", default=0.5)
    parser.add_argument("-bth", "--batch", type=int, help="batch size of training", default=128)
    parser.add_argument("-stop", "--stop", type=int, help="epoch of stopping tolerance", default=5)
    parser.add_argument("-ep", "--epoch", type=int, help="epoch of training", default=100)
    parser.add_argument("-eval", "--eval", type=int, help="evaluation iteration", default=30)
    parser.add_argument("--save_model", type=bool, help="whether to save the model parameters", default=False)
    args = parser.parse_args()

    start = time.time()
    # Read in the data
    if args.data == "part":
        train = list(read_dataset("./data/train.txt"))
        w2i = defaultdict(lambda: UNK, w2i)
        dev = list(read_dataset("./data/test.txt"))
    if args.data == "all":
        train = list(read_dataset("./full_data/topicclass-v1/topicclass/topicclass_train.txt"))
        w2i = defaultdict(lambda: UNK, w2i)
        dev = list(read_dataset("./full_data/topicclass-v1/topicclass/topicclass_test.txt"))

    train = train[:int(args.ratio * len(train))]
    # sort the training by length
    train = sorted(train, key=len)
    nwords = len(w2i)
    numtag = {'all': 16, 'part': 5}
    ntags = numtag[args.data]
    print('Load dataset for {}s'.format(round((time.time() - start) / 60, 3)))
    start = time.time()
    i2w = {v:k for k, v in w2i.items()}

    # residual = []
    # for w, i in w2i.items():
    #     if w not in i2w.values():
    #         residual.append(w)

    print('Tags {} UNK {} using time {} s'.format(ntags, len(i2w), round((time.time() - start) / 60, 3)))
    load_time = time.time()
    if args.pattern == 'rand':
        pretrained_embedding = None
        EMB_SIZE = 300
    else:
        pretrained_embedding = []
        if args.pattern == '6B100d':
            # Load Glove data
            embedding = load_embedding('./embedding/glove.6B/glove.6B.100d.txt')
            EMB_SIZE = 100

        if args.pattern == '6B200d':
            embedding = load_embedding('./embedding/glove.6B/glove.6B.200d.txt')
            EMB_SIZE = 200

        if args.pattern == '6B300d':
            embedding = load_embedding('./embedding/glove.6B/glove.6B.300d.txt')
            EMB_SIZE = 300
        UNK_embedding = np.random.rand(EMB_SIZE)
        for w in i2w.values():
            try:
                pretrained_embedding.append(embedding[w])
            except KeyError:
                # pretrained_embedding.append(np.random.rand(EMB_SIZE))
                pretrained_embedding.append(UNK_embedding)

        pretrained_embedding = np.array(pretrained_embedding).reshape((len(i2w), EMB_SIZE))

    print('Embedding Loaded time: {}s'.format(round(time.time() - load_time, 3)))
    # Define the model
    WIN_SIZE = 10
    FILTER_SIZE = args.filter
    N_EPOCH = args.epoch
    drop_out = args.dropout
    weight_norm = args.weight_norm
    early_stopping = True
    best_model = 0
    stop_tolerance = args.stop
    STOP_WARNING = 0
    BATCH = args.batch
    if args.mode == "normal":
        batch_num = int(len(train) / BATCH)
    if args.mode == "toy":
        batch_num = 2
    type = torch.LongTensor
    use_cuda = torch.cuda.is_available()
    torch.manual_seed(22)
    if use_cuda:
        type = torch.cuda.LongTensor
        device = 'cuda'
        torch.cuda.manual_seed_all(22)
        torch.cuda.seed_all()

    else:
        device = 'cpu'

    # word_dim = # k-dim word embedding
    print('Load dataset ...')

    # initialize the model
    model = CNNclass(len(i2w), EMB_SIZE, FILTER_SIZE, WIN_SIZE, drop_out, weight_norm, ntags, use_cuda, type, pretrained_embedding)
    if use_cuda:
        print('Use cuda for the model')
        model.cuda()
    criterion = torch.nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), weight_decay=1e-5)


    print('Load model ...')

    date = '%d-%d-%d-%d-%d'% (datetime.datetime.now().year, datetime.datetime.now().month, datetime.datetime.now().day,
                              datetime.datetime.now().hour, datetime.datetime.now().minute)
    folder = "./summary/{}".format(date)
    if not os.path.exists(folder):
        os.makedirs(folder)

    loss_graph = []
    train_acc_graph = []
    dev_acc_graph = []
    print('Train {} Dev {} Total {} batches '.format(len(train), len(dev), batch_num))
    for i in range(N_EPOCH):
        model.train()
        train_loss = 0.0
        train_correct = 0.0
        start = time.time()
        for ITER in range(batch_num):
            train_batch = train[i*BATCH: (i+1)*BATCH]
            WIN_SIZE = len(train_batch[-1][0])
            # Perform training
            # model.train()
            random.shuffle(train_batch)
            for _, wids, tag in train_batch:
                # Padding (can be done in the conv layer as well)
                if len(wids) < WIN_SIZE:
                    wids += [0] * (WIN_SIZE - len(wids))
                words_tensor = torch.tensor(wids).type(type)
                tag_tensor = torch.tensor([tag]).type(type)
                scores = model(words_tensor)
                predict = scores[0].argmax().item()
                if predict == tag:
                    train_correct += 1

                my_loss = criterion(scores, tag_tensor)
                train_loss += my_loss.item()
                # Do back-prop
                optimizer.zero_grad()
                my_loss.backward()
                optimizer.step()

        loss_graph.append(train_loss)
        train_acc_graph.append(train_correct/len(train))
        train_summary = "Epoch %r: train loss/sent=%.4f, acc=%.4f, time=%.2fs" % (i, train_loss/len(train), train_correct/len(train), time.time()-start)
        print(train_summary)
        with open(folder + '/summary.txt', 'a') as fp:
            fp.write(train_summary + '\n')
        fp.close()
        # Perform testing
        test_correct = 0.0
        model.eval()
        for _, wids, tag in dev:
            # Padding (can be done in the conv layer as well)
            if len(wids) < WIN_SIZE:
                wids += [0] * (WIN_SIZE - len(wids))
            words_tensor = torch.tensor(wids).type(type)
            scores = model(words_tensor)
            predict = scores[0].argmax().item()
            if predict == tag:
                test_correct += 1

        dev_acc_graph.append(test_correct/len(dev))
        if test_correct / len(dev) >= best_model:
            best_model = test_correct / len(dev)

        else:
            if args.early_stop == 'immediate':
                print('Early stop at {} epoch', i)
                pdb.set_trace()
                break

            if args.early_stop == 'no':
                pass

            if args.early_stop == 'tolerate':
                STOP_WARNING += 1
                if STOP_WARNING == stop_tolerance:
                    break

        test_summary = "iter %r: test acc=%.4f" % (i, test_correct/len(dev))
        print(test_summary)
        with open(folder + '/summary.txt', 'a') as fp:
            fp.write(test_summary + '\n')
        fp.close()


    prefix = '{}_{}_{}_'.format(args.pattern, args.batch, args.epoch)
    # Save the result
    with open(folder + '/' + prefix + 'train_loss.txt', 'wb') as fp:
        pickle.dump(loss_graph, fp)
    with open(folder + '/' + prefix + 'train_acc.txt', 'wb') as fp:
        pickle.dump(train_acc_graph, fp)
    with open(folder + '/' + prefix + 'dev_acc.txt', 'wb') as fp:
        pickle.dump(dev_acc_graph, fp)
    print('Result saved ...')



    for words, wids, tag in dev:
        calc_predict_and_activations(wids, tag, words)
        input()
